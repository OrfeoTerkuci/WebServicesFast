#!/usr/bin/env bash

# Run the script
echo "Running the script"
python3 test.py

exit 0
